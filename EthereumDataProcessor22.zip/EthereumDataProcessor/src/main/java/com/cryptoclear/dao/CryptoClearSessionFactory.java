package com.cryptoclear.dao;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistryBuilder;

import java.util.Properties;

/**
 *
 * @author SessionFactory
 *
 */
public class CryptoClearSessionFactory {

    private SessionFactory sessionFactory;

    private SessionFactory readOnlySessionFactory;

    public CryptoClearSessionFactory(final String configName)
    {
        final Configuration config = new Configuration();
        config.configure(configName);
        final ServiceRegistryBuilder serviceRegistryBuilder = new ServiceRegistryBuilder().applySettings(config
                .getProperties());
        sessionFactory = config.buildSessionFactory(serviceRegistryBuilder.buildServiceRegistry());
        readOnlySessionFactory = sessionFactory;
    }

    public CryptoClearSessionFactory(final String configName, final String dataSourceName) {
        final Configuration config = new Configuration();
        config.configure(configName);
        config.setProperty("hibernate.connection.datasource", dataSourceName);
        final ServiceRegistryBuilder serviceRegistryBuilder = new ServiceRegistryBuilder().applySettings(config
                .getProperties());
        sessionFactory = config.buildSessionFactory(serviceRegistryBuilder.buildServiceRegistry());
        readOnlySessionFactory = sessionFactory;
    }

    public CryptoClearSessionFactory(final String configName, final Properties configProperties)
    {
        final Configuration config = new Configuration();
        config.configure(configName).addProperties(configProperties);
        final ServiceRegistryBuilder serviceRegistryBuilder = new ServiceRegistryBuilder().applySettings(config.getProperties());
        sessionFactory = config.buildSessionFactory(serviceRegistryBuilder.buildServiceRegistry());
        readOnlySessionFactory = sessionFactory;
    }

    public CryptoClearSessionFactory(final String configName, final Properties readAndWrite, final Properties readOnly) {
        final Configuration readAndWriteConfig = new Configuration();
        readAndWriteConfig.configure(configName).addProperties(readAndWrite);
        final ServiceRegistryBuilder readAndWriteBuilder = new ServiceRegistryBuilder().applySettings(readAndWriteConfig.getProperties());
        sessionFactory = readAndWriteConfig.buildSessionFactory(readAndWriteBuilder.buildServiceRegistry());

        final Configuration readOnlyConfig = new Configuration();
        readOnlyConfig.configure(configName).addProperties(readOnly);
        final ServiceRegistryBuilder readOnlyBuilder = new ServiceRegistryBuilder().applySettings(readOnlyConfig.getProperties());
        readOnlySessionFactory = readOnlyConfig.buildSessionFactory(readOnlyBuilder.buildServiceRegistry());
    }

    public CryptoClearSessionFactory(final String configName, final String masterDatasource, final String replicaDatasource)
    {
        final Configuration config = new Configuration();
        config.configure(configName);
        config.setProperty("hibernate.connection.datasource", masterDatasource);
        final ServiceRegistryBuilder serviceRegistryBuilder = new ServiceRegistryBuilder().applySettings(config
                .getProperties());
        sessionFactory = config.buildSessionFactory(serviceRegistryBuilder.buildServiceRegistry());


        final Configuration config1 = new Configuration();
        config1.configure(configName);
        config1.setProperty("hibernate.connection.datasource",replicaDatasource);
        final ServiceRegistryBuilder serviceRegistryBuilder1 = new ServiceRegistryBuilder().applySettings(config1
                .getProperties());
        readOnlySessionFactory = config1.buildSessionFactory(serviceRegistryBuilder1.buildServiceRegistry());
    }

    /**
     * @assert.post result != null
     */
    public SessionFactory getSessionFactory()
    {
        return sessionFactory;
    }
}

