package com.cryptoclear.model;

import java.io.Serializable;
/**
 * BonusImpl
 */
public class BlockImpl implements Serializable {

    private long id;
    private Long blockNumber;
    private String processedStatus;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Long getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(final Long blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getProcessedStatus() {
        return processedStatus;
    }

    public void setProcessedStatus(final String processedStatus) {
        this.processedStatus = processedStatus;
    }
}
