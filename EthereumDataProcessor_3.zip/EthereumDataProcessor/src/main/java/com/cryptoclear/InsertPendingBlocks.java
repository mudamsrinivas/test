package com.cryptoclear;

import com.cryptoclear.dao.EthereumDao;
import com.cryptoclear.model.BlockImpl;
import com.cryptoclear.svc.EthereumSvcImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.web3j.protocol.core.methods.response.EthBlock;

import java.util.ArrayList;
import java.util.List;

public class InsertPendingBlocks {
    private static Logger logger = LoggerFactory.getLogger(InsertPendingBlocks.class);
    private static final int NUMBER_OF_BLOcKS = 10000;
    private static final int ONE = 1;
    public static void main(String[] args) {
        logger.info("** started inserting pending blocks *** ");
        try {
            final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("AppContext.xml");
            final EthereumDao ethereumDao = (EthereumDao) ctx.getBean("ethereumDao");
            final EthereumSvcImpl ethereumSvc = (EthereumSvcImpl) ctx.getBean("ethereumSvcImpl");
            final BlockImpl recentBlock = ethereumDao.getRecentBlock();
            long recentBlockNumber = 0;
            if (recentBlock != null) {
                 recentBlockNumber = recentBlock.getBlockNumber();
            }else {
                final EthBlock.Block apiBlock = ethereumSvc.getLatestBlockFromAPI();
                recentBlockNumber = apiBlock.getNumber().longValue();
            }
            if(recentBlockNumber > 0){
                final long startBlockNumber = recentBlockNumber - ONE;
                final long endBlockNumber = recentBlockNumber - NUMBER_OF_BLOcKS;
                logger.info("startBlockNumber::" + startBlockNumber);
                logger.info("EndBlockNumber::" + endBlockNumber);
                List<BlockImpl> blockList = new ArrayList<>();
                if (endBlockNumber >= ONE) {
                    for (long i = startBlockNumber; i >= endBlockNumber; i--) {
                        final BlockImpl block = new BlockImpl();
                        block.setBlockNumber(i);
                        block.setProcessedStatus("pending");
                        blockList.add(block);
                    }
                    ethereumDao.saveOrUpdateBlock(blockList);
                }
            }
        }catch(final Exception e){
            logger.error("main "+ e, e);
        }
        logger.info(NUMBER_OF_BLOcKS+ " Blocks inserted with pending state");
    }

}
