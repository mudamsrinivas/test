package com.cryptoclear.multithread;


import com.cryptoclear.dao.EthereumDao;
import com.cryptoclear.model.BlockImpl;
import com.cryptoclear.svc.EthereumSvcImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class EthereumConsumer implements Runnable {

  private static Logger logger = LoggerFactory.getLogger(EthereumConsumer.class);

  private final AtomicBoolean isShuttingDown = new AtomicBoolean(false);
  private EthereumDao ethereumDao;

  public void setEthereumDao(final EthereumDao ethereumDao) {
    this.ethereumDao = ethereumDao;
  }
    private EthereumSvcImpl ethereumSvc;

    public void setEthereumSvc(final EthereumSvcImpl ethereumSvc) {
        this.ethereumSvc = ethereumSvc;
    }

  @Override
  public void run() {
    while (!isShuttingDown.get()) {
        final BlockImpl blocks = ethereumDao.getPendingBlock();
     if(blocks != null ){
      try {
          ethereumSvc.processData(blocks);
       } catch (final Exception e) {
        logger.error("Encountered recoverable exception, preparing to retry, ..."+e, e);
        performSimpleBackoff();
      }
    }else{
      logger.info("completed processing");
      isShuttingDown.set(true);
    }
    }

  }


  public void shutdown() {

    isShuttingDown.set(true);
  }

  private void performSimpleBackoff() {

    try {
      logger.warn("Back off for a configured time...");
      Thread.sleep(10);
    } catch (InterruptedException ie) {

      Thread.currentThread().interrupt();
      logger.warn("Back off was interrupted, waking up earlier than expected...", ie);
    }
  }
}