package com.cryptoclear.svc;

import com.cryptoclear.client.BlockChainClient;
import com.cryptoclear.dao.EthereumDao;
import com.cryptoclear.model.BlockImpl;
import com.cryptoclear.model.EthLogImpl;
import com.cryptoclear.model.TransactionTraceImpl;
import org.web3j.protocol.core.methods.response.EthBlock;
import org.web3j.protocol.core.methods.response.EthLog;
import org.web3j.protocol.parity.methods.response.Trace;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * TransactionTraceSvcImpl
 */

public class EthereumSvcImpl {

    private EthereumDao ethereumDao;
    private BlockChainClient blockChainClient;

    public EthereumSvcImpl(final EthereumDao bonusDao) {
        this.ethereumDao =  bonusDao;
    }

    public void setBlockChainClient(final BlockChainClient blockChainClient) {
        this.blockChainClient = blockChainClient;
    }

    public TransactionTraceImpl getBonusLimitByBonusId(final long bonusId){

        return ethereumDao.getTransactionTraceById(bonusId);
    }

    public boolean saveOrUpdateTransactionTrace(final TransactionTraceImpl transactionTrace){
        return ethereumDao.saveOrUpdateTransactionTrace(transactionTrace);
    }
    public EthBlock.Block getLatestBlockFromAPI() throws Exception{
        final EthBlock.Block ethBlock =  blockChainClient.getLatestBlock();
       return ethBlock;
    }


    public void processData(){
        try{
            final long starTime = System.currentTimeMillis();
            System.out.println();
            final List<BlockImpl> blocks = ethereumDao.getPendingBlocks(100);
            for(BlockImpl block: blocks){
                final EthBlock.Block ethBlock =  blockChainClient.getLatestBlock(block.getBlockNumber());
                final List<EthLog.LogResult> logResults =  blockChainClient.getEthLogsByBlockHash(ethBlock.getHash());
                processTraceTransaction(ethBlock);
                processEthLogs(logResults);
                block.setProcessedStatus("completed");
                ethereumDao.saveOrUpdateBlock(block);
            }
            final long endTime = System.currentTimeMillis();
            final long totalTime = endTime - starTime;
            System.out.println("total time in minutes"+ TimeUnit.MILLISECONDS.toMinutes(totalTime));

        }catch(Exception e){
          e.printStackTrace();
        }
    }

    public void processEthLogs(final List<EthLog.LogResult> logResults){
        try{
            if(logResults != null){
                System.out.println("logs size::"+logResults.size());
                List<EthLogImpl> ethLogList = new ArrayList<>();
                for(EthLog.LogResult log: logResults){
                    final EthLog.LogObject logObject = (EthLog.LogObject)log.get();
                    final EthLogImpl ethLogImpl = new EthLogImpl();
                    ethLogImpl.setAddress(logObject.getAddress());
                    ethLogImpl.setBlockHash(logObject.getBlockHash());
                    ethLogImpl.setBlockNumber(convertLong(logObject.getBlockNumber()));
                    ethLogImpl.setData(logObject.getData());
                    ethLogImpl.setTransactionHash(logObject.getTransactionHash());
                    ethLogImpl.setTransactionIndex(convertLong(logObject.getTransactionIndex()));
                    final String topics = logObject.getTopics().stream().map(String::valueOf)
                            .collect(Collectors.joining(","));
                    ethLogImpl.setTopics(topics);
                    ethLogImpl.setType(logObject.getType());
                    ethLogImpl.setLogIndex(convertLong(logObject.getLogIndex()));
                    ethLogImpl.setRemoved(logObject.get().isRemoved());
                    ethLogList.add(ethLogImpl);
                }
                ethereumDao.saveOrUpdateEthLog(ethLogList);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }
    public void processTraceTransaction(final EthBlock.Block ethBlock ){
        try{
            if( ethBlock != null){
                System.out.println("Parent Block hash:: "+ethBlock+" ParentBlock::\t"+ethBlock.getNumber().toString()+ " raw number: "+ ethBlock.getNumberRaw()+" Transaction Count:"+ethBlock.getTransactions().size());
                final List<Trace> traces = blockChainClient.getTraceByBlockNumber(ethBlock.getNumber());
                if(traces != null && traces.size() > 0){
                    System.out.println("trace Size::"+ traces.size());
                    final List<TransactionTraceImpl> transactionTraceList = new ArrayList<TransactionTraceImpl>();
                    for(final Trace trace:traces){
                        final TransactionTraceImpl transactionTraceImpl = new TransactionTraceImpl();

                        transactionTraceImpl.setBlockHash(trace.getBlockHash());
                        transactionTraceImpl.setBlockNumber(convertLong(trace.getBlockNumber()));
                        transactionTraceImpl.setBlockTimestamp(new Timestamp(convertLong(ethBlock.getTimestamp())*1000));
                        transactionTraceImpl.setSubTraces(convertLong(trace.getSubtraces()));
                        final String traceAddress = trace.getTraceAddress().stream().map(String::valueOf)
                                .collect(Collectors.joining(","));
                        transactionTraceImpl.setTraceAddress(traceAddress);
                        transactionTraceImpl.setTraceType(trace.getType());
                        transactionTraceImpl.setError(trace.getError());
                        transactionTraceImpl.setTransactionHash(trace.getTransactionHash());
                        transactionTraceImpl.setTransactionIndex(convertLong(trace.getTransactionPosition()));
                        final Trace.Result result = trace.getResult();
                        if(result != null){
                            transactionTraceImpl.setGasUsed(convertLong(result.getGasUsed()));
                            transactionTraceImpl.setOutput(result.getOutput());
                        }
                        if(trace.getType().equalsIgnoreCase("call")) {
                            Trace.CallAction action = (Trace.CallAction )trace.getAction();
                            transactionTraceImpl.setCallType(action.getCallType());
                            transactionTraceImpl.setFromAddress(action.getFrom());
                            transactionTraceImpl.setToAddress(action.getTo());
                            transactionTraceImpl.setValue(convertLong(action.getValue()));
                            transactionTraceImpl.setGas(convertLong(action.getGas()));
                            transactionTraceImpl.setInput(action.getInput());
                        }else if(trace.getType().equalsIgnoreCase("suicide")) {
                            Trace.SuicideAction suicideAction = (Trace.SuicideAction )trace.getAction();
                            suicideAction.getAddress();
                        }
                        final String address = trace.getTraceAddress().stream().map(String::valueOf)
                                .collect(Collectors.joining("_"));
                        transactionTraceImpl.setTraceId(trace.getType()+"_"+trace.getTransactionHash()+"_"+address);
                        transactionTraceList.add(transactionTraceImpl);

                    }
                    ethereumDao.saveOrUpdateTransactionTrace(transactionTraceList);
                }
            }
        }catch(final Exception  e){
            e.printStackTrace();
        }
    }
 private Long convertLong(final BigInteger bigInteger){
        if(bigInteger != null){
            return  bigInteger.longValue();
        }
        return 0l;
 }
}