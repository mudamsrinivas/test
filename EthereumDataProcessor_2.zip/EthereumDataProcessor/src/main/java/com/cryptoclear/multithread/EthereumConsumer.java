package com.cryptoclear.multithread;


import com.cryptoclear.dao.EthereumDao;
import com.cryptoclear.model.BlockImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.exception.JDBCConnectionException;
import java.util.concurrent.atomic.AtomicBoolean;

public class EthereumConsumer implements Runnable {

  private static final Log logger = LogFactory.getLog(EthereumConsumer.class);

  private final AtomicBoolean isShuttingDown = new AtomicBoolean(false);
  private EthereumDao ethereumDao;

  public void setEthereumDao(final EthereumDao ethereumDao) {
    this.ethereumDao = ethereumDao;
  }

  @Override
  public void run() {
    boolean isRetrying = false;
    while (!isShuttingDown.get()) {
      try {
        final BlockImpl blockImpl = ethereumDao.getPendingBlock();
        if(blockImpl != null){
          blockImpl.setProcessedStatus("inProgress");
          ethereumDao.saveOrUpdateBlock(blockImpl);
          final BlockImpl parentBlockImpl = new BlockImpl();
          parentBlockImpl.setBlockNumber(blockImpl.getBlockNumber()-1);
          parentBlockImpl.setProcessedStatus("pending");
          ethereumDao.saveOrUpdateBlock(parentBlockImpl);
          blockImpl.setProcessedStatus("completed");
          ethereumDao.saveOrUpdateBlock(blockImpl);
        }
      } catch (JDBCConnectionException e) {
        logger.warn("Encountered recoverable exception, preparing to retry, ...", e);
        isRetrying = true;
        performSimpleBackoff();
        //retry by continuing the loop
        continue;
      }

    }


  }





  public void shutdown() {

    isShuttingDown.set(true);
  }

  private void performSimpleBackoff() {

    try {

      logger.warn("Back off for a configured time...");

      Thread.sleep(10);

    } catch (InterruptedException ie) {

      Thread.currentThread().interrupt();
      logger.warn("Back off was interrupted, waking up earlier than expected...", ie);
    }
  }
}