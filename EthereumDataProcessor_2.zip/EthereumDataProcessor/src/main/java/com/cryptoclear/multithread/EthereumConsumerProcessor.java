package com.cryptoclear.multithread;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class EthereumConsumerProcessor {

  private static Log logger = LogFactory.getLog(EthereumConsumerProcessor.class);

  public static void main(String[] args) throws Exception {

    logger.info("********** Starting EthereumConsumerProcessor ************");
    logger.info("JAVA VERSION: " + System.getProperty("java.version"));
    logger.info("JAVA HOME: " + System.getenv("JAVA_HOME"));

    int index = 0;
    final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("AppContext.xml");
    final Integer threadCount = 10;
    final EthereumConsumer[] ethereumConsumers = new EthereumConsumer[threadCount];
    final Queue<Thread> allThreads = new ConcurrentLinkedQueue<>();
    while (index < threadCount) {
      final EthereumConsumer ethereumConsumer = ctx.getBean(EthereumConsumer.class);
      ethereumConsumers[index] = ethereumConsumer;
      final Thread consumerThread = new Thread(ethereumConsumer);
      allThreads.add(consumerThread);
      index++;
    }
    try {
      for (final Thread thread : allThreads) {
        thread.start();
      }
    } catch (Exception e) {
      System.out.println(e);

    } finally {
      addShutdownHook(ethereumConsumers, allThreads);
    }
  }

  private static void addShutdownHook(EthereumConsumer[] ethereumConsumers, Queue<Thread> allThreads) {
    Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
      @Override
      public void run() {

        logger.info("********* Going to shutdown all consumers *************** ");
        for (EthereumConsumer ethereumConsumer : ethereumConsumers) {
          ethereumConsumer.shutdown();
        }
      }
    }));
  }
}
