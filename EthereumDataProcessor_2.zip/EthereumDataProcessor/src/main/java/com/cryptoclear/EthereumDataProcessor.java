package com.cryptoclear;

import com.cryptoclear.dao.EthereumDao;
import com.cryptoclear.model.BlockImpl;
import com.cryptoclear.svc.EthereumSvcImpl;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EthereumDataProcessor {

    public static void main(String[] args) {
        System.out.println(" **** welcome **** ");
        final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("AppContext.xml");
        final EthereumSvcImpl svc = (EthereumSvcImpl) ctx.getBean("ethereumSvcImpl");
        svc.processData();
        System.out.println("Process completed");
    }
}
