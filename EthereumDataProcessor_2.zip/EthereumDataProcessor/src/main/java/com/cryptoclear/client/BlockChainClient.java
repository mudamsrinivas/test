package com.cryptoclear.client;

import org.web3j.crypto.WalletFile;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.Web3jService;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.DefaultBlockParameterNumber;
import org.web3j.protocol.core.Request;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.EthBlock;
import org.web3j.protocol.core.methods.response.EthLog;
import org.web3j.protocol.http.HttpService;
import org.web3j.protocol.parity.Parity;
import org.web3j.protocol.parity.methods.response.ParityExportAccount;
import org.web3j.protocol.parity.methods.response.ParityTracesResponse;
import org.web3j.protocol.parity.methods.response.Trace;

import java.math.BigInteger;
import java.util.List;

public class BlockChainClient {
    final static String blockChainURL = "https://compatible-stylish-patina.quiknode.pro/8cdeef86796f183515b75e8cd842e4ac4cf1e5bd";
    private static Web3jService service = new HttpService(blockChainURL);
    private static Web3j web3j = Web3j.build(service);
    private static Parity parity = Parity.build(service);

    public List<Trace> getTraceByBlockNumber(BigInteger blockNum) throws Exception {
        final DefaultBlockParameterNumber number = new DefaultBlockParameterNumber(blockNum);
       final Request<?, ParityTracesResponse> request = parity.traceBlock(number);
        final ParityTracesResponse response = request.send();
        return response.getTraces();
    }

    public  List<Trace> getTraceTransactionByTransactionHash(final String hash) throws Exception {
        final Request<?, ParityTracesResponse> request = parity.traceTransaction(hash);
       final  ParityTracesResponse response = request.send();

        return response.getTraces();
    }
    public  WalletFile
    exportAccount(String address, String password) throws Exception {
        Request<?, ParityExportAccount> request = parity.parityExportAccount(address, password);
        ParityExportAccount response = request.send();
        return response.getWallet();
    }

    public  EthBlock.Block getLatestBlock(final Long blockNumber) throws Exception{
        final DefaultBlockParameterNumber defaultBlockParameterNumber = new DefaultBlockParameterNumber(blockNumber);
        EthBlock.Block block = web3j.ethGetBlockByNumber(defaultBlockParameterNumber, true).send().getBlock();
    return block;
    }

    public  EthBlock.Block getLatestBlock() throws Exception{
        EthBlock.Block block = web3j.ethGetBlockByNumber(DefaultBlockParameterName.LATEST, true).send().getBlock();
        return block;
    }

    public  EthBlock.Block getBlockByHash(final String blockNumberHash) throws Exception{
        EthBlock.Block  block = web3j.ethGetBlockByHash(blockNumberHash, true).send().getBlock();
        return block;
    }

    public  List<EthLog.LogResult> getEthLogsByBlockHash(final String blockNumberHash) throws Exception{
        final EthFilter ethFilter = new EthFilter(blockNumberHash);
        final List<EthLog.LogResult> logsResults = web3j.ethGetLogs(ethFilter).send().getLogs();
        return logsResults;
    }
}
