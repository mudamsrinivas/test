package com.cryptoclear;

import com.cryptoclear.dao.EthereumDao;
import com.cryptoclear.model.BlockImpl;
import com.cryptoclear.svc.EthereumSvcImpl;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.web3j.protocol.core.methods.response.EthBlock;

import java.util.ArrayList;
import java.util.List;

public class InsertPendingBlocks {

    private static final int NUMBER_OF_BLOcKS = 10000;
    private static final int ONE = 1;
    public static void main(String[] args) {
        System.out.println(" **** welcome **** ");
        try {
            final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("AppContext.xml");
            final EthereumDao ethereumDao = (EthereumDao) ctx.getBean("ethereumDao");
            final EthereumSvcImpl ethereumSvc = (EthereumSvcImpl) ctx.getBean("ethereumSvcImpl");
            final BlockImpl recentBlock = ethereumDao.getRecentBlock();
            long recentBlockNumber = 0;
            if (recentBlock != null) {
                 recentBlockNumber = recentBlock.getBlockNumber();
            }else {
                final EthBlock.Block apiBlock = ethereumSvc.getLatestBlockFromAPI();
                recentBlockNumber = apiBlock.getNumber().longValue();
            }
            if(recentBlockNumber > 0){
                final long startBlockNumber = recentBlockNumber - ONE;
                final long endBlockNumber = recentBlockNumber - NUMBER_OF_BLOcKS;
                System.out.println("startBlockNumber::" + startBlockNumber);
                System.out.println("EndBlockNumber::" + endBlockNumber);
                List<BlockImpl> blockList = new ArrayList<>();
                if (endBlockNumber >= ONE) {
                    for (long i = startBlockNumber; i >= endBlockNumber; i--) {
                        System.out.println(i);
                        final BlockImpl block = new BlockImpl();
                        block.setBlockNumber(i);
                        block.setProcessedStatus("pending");
                        blockList.add(block);
                    }
                    ethereumDao.saveOrUpdateBlock(blockList);
                }
            }
        }catch(Exception e){
                e.printStackTrace();
        }
        System.out.println(NUMBER_OF_BLOcKS+ " Blocks inserted with pending state");
    }

}
