package com.cryptoclear;

import com.cryptoclear.svc.EthereumSvcImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EthereumDataProcessor {
    private static Logger logger = LoggerFactory.getLogger(EthereumDataProcessor.class);
    public static void main(String[] args) {
        logger.info(" **** welcome **** ");
        final ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("AppContext.xml");
        final EthereumSvcImpl svc = (EthereumSvcImpl) ctx.getBean("ethereumSvcImpl");
        //svc.processData();
        logger.info("Process completed");
    }
}
