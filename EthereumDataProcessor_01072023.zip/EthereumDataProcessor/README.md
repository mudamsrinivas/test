# cryptoclear ethereum data processor 

This repo has a Java standalone application that uses the [Hibernate ORM](http://hibernate.org/) to talk to [PostgreSQL](https://www.postgresql.org/).

For instructions on running the code in this repo
# Run the code
./gradlew run
