#!/bin/bash

export JAVA_HOME=$JAVA_HOME

cd /opt/work/EthereumDataProcessor

./gradlew run

## Include these properties for AWS Secret Manager - -Dawssm.local.override=false -Dawssm.app.prefix=/us/batchapp/nonprod
##JVM_OPTS=${JVM_OPTS:="-Xms1024M -Xmx1024M -Dlog4j.configurationFile=../ebates/log4j2.xml -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=3036 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false"}
##$JAVA_HOME/bin/java -client ${JVM_OPTS} -cp "../ebates/:../target/*" com.mkyong.hashing.App