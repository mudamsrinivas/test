package com.cryptoclear.dao;

import com.cryptoclear.model.BlockImpl;
import com.cryptoclear.model.EthLogImpl;
import com.cryptoclear.model.TransactionTraceImpl;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * TransactionTraceDao
 */

public class EthereumDao {

    private static Logger logger = LoggerFactory.getLogger(EthereumDao.class);

    private CryptoClearSessionFactory sessionFactory;

    public EthereumDao(final CryptoClearSessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public TransactionTraceImpl getTransactionTraceById(final long id) {
        Session session = null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            final Query query = session.getNamedQuery("getTransactionTraceById");
            query.setLong("id", id);
            final Object result = query.uniqueResult();
            if (result != null) {
                final TransactionTraceImpl transactionTrace = (TransactionTraceImpl)result;
                return transactionTrace;
            }
        } catch (final Exception e) {
            logger.error("getTransactionTraceById "+e, e);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return null;
    }
    public boolean saveOrUpdateTransactionTrace(final List<TransactionTraceImpl> transactionTraceList){
        Session session=null;
        Transaction txn=null;
        long blockNumber =0l;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            int i=0;
            for ( TransactionTraceImpl transactionTraceImpl :transactionTraceList) {
                try{
                    blockNumber = transactionTraceImpl.getBlockNumber();
                    session.save(transactionTraceImpl);
                    i++;
                    if( i % 50 == 0 ) { // Same as the JDBC batch size
                        //flush a batch of inserts and release memory:
                        session.flush();
                        session.clear();
                    }
                }catch(Exception e){
                    logger.error("Error in saveOrUpdateTransactionTrace Block number:: "+ blockNumber +" "+e, e);
                }
            }
            txn.commit();
            return true;
        } catch (final Exception e) {
            logger.error("Error in saveOrUpdateTransactionTrace Block number:: "+ blockNumber +" "+e, e);
            if (txn!=null) {
                txn.rollback();
                return false;
            }
        } finally {
            if (session!=null) {
                session.close();
            }
        }
        return false;
    }
    public boolean saveOrUpdateTransactionTrace(final TransactionTraceImpl transactionTraceImpl){
        Session session=null;
        Transaction txn=null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            session.save(transactionTraceImpl);
            txn.commit();
            return true;
        } catch (final Exception e) {
            logger.error("saveOrUpdateTransactionTrace "+e, e);
            if (txn!=null) {
                txn.rollback();
                return false;
            }
        } finally {
            if (session!=null) {
                session.close();
            }
        }
        return false;
    }

    public BlockImpl getBlockById(final long id) {
        Session session = null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            final Query query = session.getNamedQuery("getBlockById");
            query.setLong("id", id);
            final Object result = query.uniqueResult();
            if (result != null) {
                final BlockImpl blockImpl = (BlockImpl)result;
                return blockImpl;
            }
        } catch (final Exception e) {
            logger.error("getBlockById "+e, e);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return null;
    }

    public BlockImpl getBlockByBlockNumber(final long blockNumber) {
        Session session = null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            final Query query = session.getNamedQuery("getBlockByBlockNumber");
            query.setLong("blockNumber", blockNumber);
            final Object result = query.uniqueResult();
            if (result != null) {
                final BlockImpl blockImpl = (BlockImpl)result;
                return blockImpl;
            }
        } catch (final Exception e) {
            logger.error("getBlockByBlockNumber "+e, e);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return null;
    }

    public BlockImpl getPendingBlock() {
        Session session = null;
        Transaction txn=null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            final Query query = session.getNamedQuery("getPendingBlock").setLockMode("pblock", LockMode.PESSIMISTIC_WRITE);
            query.setMaxResults(1);
            final Object result = query.uniqueResult();
            if (result != null) {
                final BlockImpl blockImpl = (BlockImpl)result;
                blockImpl.setProcessedStatus("inProgress");
                session.saveOrUpdate(blockImpl);
                txn.commit();
                return blockImpl;
            }
        } catch (final Exception e) {
            txn.rollback();
            logger.error("getPendingBlock "+e, e);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return null;
    }

    public List<BlockImpl> getPendingBlocks(final int limit ) {
        Session session = null;
        Transaction txn=null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            final Query query = session.getNamedQuery("getPendingBlock").setLockMode("pblock", LockMode.PESSIMISTIC_WRITE);
            query.setMaxResults(limit);
            final Object result = query.list();
            if (result != null) {
                final List<BlockImpl> blockList = (List<BlockImpl>)result;
                return blockList;
            }
            if (result != null) {
                final List<BlockImpl> blockList = (List<BlockImpl>)result;
                for(BlockImpl block:blockList){
                    block.setProcessedStatus("inProgress");
                    session.saveOrUpdate(block);
                }
                txn.commit();
                return blockList;
            }
        } catch (final Exception e) {
            logger.error("getPendingBlocks "+e, e);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return null;
    }

    public BlockImpl getRecentBlock() {
        Session session = null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            final Query query = session.getNamedQuery("getRecentBlock");
            query.setMaxResults(1);
            final Object result = query.uniqueResult();
            if (result != null) {
                final BlockImpl blockImpl = (BlockImpl)result;
                return blockImpl;
            }
        } catch (final Exception e) {
            logger.error("getRecentBlock "+e, e);
        } finally {
            if (session != null) {
                session.close();
            }
        }
        return null;
    }

    public boolean saveOrUpdateBlock(final BlockImpl blockImpl){
        Session session=null;
        Transaction txn=null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            session.saveOrUpdate(blockImpl);
            txn.commit();
            return true;
        } catch (final Exception e) {
            logger.error("saveOrUpdateBlock "+e, e);
            if (txn!=null) {
                txn.rollback();
                return false;
            }
        } finally {
            if (session!=null) {
                session.close();
            }
        }
        return false;
    }


    public boolean saveOrUpdateBlock(final List<BlockImpl> blockList){
        Session session=null;
        Transaction txn=null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            int i=0;
            for ( BlockImpl blockImpl :blockList) {
                try{
                    session.save(blockImpl);
                    i++;
                    if( i % 50 == 0 ) { // Same as the JDBC batch size
                        //flush a batch of inserts and release memory:
                        session.flush();
                        session.clear();
                    }
                }catch(Exception e){
                    logger.error("saveOrUpdateBlock "+e, e);
                }
            }
            txn.commit();
            return true;
        } catch (final Exception e) {
            logger.error("saveOrUpdateBlock "+e, e);
            if (txn!=null) {
                txn.rollback();
                return false;
            }
        } finally {
            if (session!=null) {
                session.close();
            }
        }
        return false;
    }

    public boolean saveOrUpdateEthLog(final EthLogImpl ethLogImpl){
        Session session=null;
        Transaction txn=null;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            session.saveOrUpdate(ethLogImpl);
            txn.commit();
            return true;
        } catch (final Exception e) {
            logger.error("saveOrUpdateEthLog "+e, e);
            if (txn!=null) {
                txn.rollback();
                return false;
            }
        } finally {
            if (session!=null) {
                session.close();
            }
        }
        return false;
    }

    public boolean saveOrUpdateEthLog(final List<EthLogImpl> ethLogList){
        Session session=null;
        Transaction txn=null;
        long blockNumber = 0l;
        try {
            session = sessionFactory.getSessionFactory().openSession();
            txn = session.beginTransaction();
            int i=0;
            for ( EthLogImpl ethLog :ethLogList) {
                try{
                    blockNumber = ethLog.getBlockNumber();
                    session.save(ethLog);
                    i++;
                    if( i % 50 == 0 ) { // Same as the JDBC batch size
                        //flush a batch of inserts and release memory:
                        session.flush();
                        session.clear();
                    }
                }catch(Exception e){
                    logger.error("Error saveOrUpdateEthLog Block number::"+blockNumber +" "+e, e);
                    return false;
                }
            }
            txn.commit();
            return true;
        } catch (final Exception e) {
            logger.error("Error saveOrUpdateEthLog Block number::"+blockNumber +" "+e, e);
            if (txn!=null) {
                txn.rollback();
                return false;
            }
        } finally {
            if (session!=null) {
                session.close();
            }
        }
        return false;
    }

}
