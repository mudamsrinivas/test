package com.cryptoclear.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * BonusImpl
 */
public class BlockImpl implements Serializable {

    private long id;
    private Long blockNumber;
    private String processedStatus;
    private String blockHash;
    private String rawNumber;
    private Timestamp blockTimestamp;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Long getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(final Long blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getProcessedStatus() {
        return processedStatus;
    }

    public void setProcessedStatus(final String processedStatus) {
        this.processedStatus = processedStatus;
    }

    public String getBlockHash() {
        return blockHash;
    }

    public void setBlockHash(final String blockHash) {
        this.blockHash = blockHash;
    }

    public String getRawNumber() {
        return rawNumber;
    }

    public void setRawNumber(final String rawNumber) {
        this.rawNumber = rawNumber;
    }

    public Timestamp getBlockTimestamp() {
        return blockTimestamp;
    }

    public void setBlockTimestamp(Timestamp blockTimestamp) {
        this.blockTimestamp = blockTimestamp;
    }
}
