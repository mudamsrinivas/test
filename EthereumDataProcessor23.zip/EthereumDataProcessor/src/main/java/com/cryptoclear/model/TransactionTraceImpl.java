package com.cryptoclear.model;



import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;

/**
 * BonusImpl
 */
public class TransactionTraceImpl implements Serializable {

    private long id;
    private Long blockNumber;

    private String transactionHash;
    private Long transactionIndex;
    private Long value;
    private String input;
    private String output;
    private String rewardType;
    private String callType;
    private String traceType;
    private Long gas;
    private Long gasUsed;
    private Long  subTraces;
    private String  traceAddress;
    private String  error;
    private Integer  status;
    private Timestamp blockTimestamp;
    private String blockHash;
    private String traceId;

    private String fromAddress;
    private String toAddress;

    public long getId() {
        return id;
    }

    public void setId(final long id) {
        this.id = id;
    }

    public Long getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(final Long blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String getTransactionHash() {
        return transactionHash;
    }

    public void setTransactionHash(final String transactionHash) {
        this.transactionHash = transactionHash;
    }

    public String getFromAddress() {
        return fromAddress;
    }

    public void setFromAddress(final String fromAddress) {
        this.fromAddress = fromAddress;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(final String toAddress) {
        this.toAddress = toAddress;
    }

    public Long getTransactionIndex() {
        return transactionIndex;
    }

    public void setTransactionIndex(Long transactionIndex) {
        this.transactionIndex = transactionIndex;
    }

    public Long getValue() {
        return value;
    }

    public void setValue(final Long value) {
        this.value = value;
    }

    public String getInput() {
        return input;
    }

    public void setInput(final String input) {
        this.input = input;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(final String output) {
        this.output = output;
    }

    public String getRewardType() {
        return rewardType;
    }

    public void setRewardType(final String rewardType) {
        this.rewardType = rewardType;
    }

    public String getCallType() {
        return callType;
    }

    public void setCallType(final String callType) {
        this.callType = callType;
    }

    public String getTraceType() {
        return traceType;
    }

    public void setTraceType(final String traceType) {
        this.traceType = traceType;
    }

    public Long getGas() {
        return gas;
    }

    public void setGas(final Long gas) {
        this.gas = gas;
    }

    public Long getGasUsed() {
        return gasUsed;
    }

    public void setGasUsed(final Long gasUsed) {
        this.gasUsed = gasUsed;
    }

    public Long getSubTraces() {
        return subTraces;
    }

    public void setSubTraces(final Long subTraces) {
        this.subTraces = subTraces;
    }

    public String getTraceAddress() {
        return traceAddress;
    }

    public void setTraceAddress(final String traceAddress) {
        this.traceAddress = traceAddress;
    }

    public String getError() {
        return error;
    }

    public void setError(final String error) {
        this.error = error;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(final Integer status) {
        this.status = status;
    }

    public Timestamp getBlockTimestamp() {
        return blockTimestamp;
    }

    public void setBlockTimestamp(final Timestamp blockTimestamp) {
        this.blockTimestamp = blockTimestamp;
    }

    public String getBlockHash() {
        return blockHash;
    }

    public void setBlockHash(final String blockHash) {
        this.blockHash = blockHash;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(final String traceId) {
        this.traceId = traceId;
    }
}
